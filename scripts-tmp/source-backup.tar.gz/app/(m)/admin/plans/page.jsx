"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import {
  Search,
  Edit2,
  Trash2,
  Plus,
  Calendar,
  TrendingUp,
  CheckCircle,
  XCircle,
  Layers,
} from "lucide-react";
import { toast } from "react-hot-toast";
import { api } from "@/lib/axios";

export default function PlansPage() {
  const [plans, setPlans] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const searchTimeoutRef = useRef(null);

  // Fetch plans
  const fetchPlans = async () => {
    setIsLoading(true);

    try {
      const params = new URLSearchParams();
      if (searchQuery) {
        params.append("search", searchQuery);
      }

      const response = await api.get(`/admin/plan-list.php?${params}`);
      const res = response.data;

      if (res.success) {
        setPlans(res.plans || []);
      } else {
        toast.error(res.message || "Failed to load trading plans");
      }
    } catch (error) {
      console.error("Fetch plans error:", error);
      toast.error(
        error.response?.data?.message || "Failed to load trading plans",
      );
    } finally {
      setIsLoading(false);
    }
  };

  // Delete plan
  const deletePlan = async (planId, planName) => {
    if (
      !confirm(
        `Are you sure you want to delete trading plan "${planName}"? This action cannot be undone.`,
      )
    ) {
      return;
    }

    try {
      const response = await api.post("/admin/plan-delete.php", { id: planId });
      const res = response.data;

      if (res.success) {
        toast.success(res.message || "Trading plan deleted successfully!");
        await fetchPlans();
      } else {
        toast.error(res.message || "Failed to delete trading plan");
      }
    } catch (error) {
      console.error("Delete plan error:", error);
      toast.error(
        error.response?.data?.message || "Failed to delete trading plan",
      );
    }
  };

  // Search with debounce
  const handleSearch = (e) => {
    const value = e.target.value;
    clearTimeout(searchTimeoutRef.current);
    searchTimeoutRef.current = setTimeout(() => {
      setSearchQuery(value);
    }, 300);
  };

  // Format currency/amount
  const formatAmount = (amount) => {
    if (!amount) return "Not set";
    return `$${amount}`;
  };

  // Get status badge class
  const getStatusClass = (status) => {
    return status === "active" ? "active" : "inactive";
  };

  // Load plans on mount
  useEffect(() => {
    fetchPlans();
  }, [searchQuery]);

  return (
    <div className="mx-auto max-w-7xl p-4 lg:p-6">
      {/* Page Header */}
      <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold text-zinc-900 dark:text-white lg:text-4xl">
            Trading Plans Management
          </h1>
          <p className="mt-1 text-sm text-zinc-500 dark:text-[#8b93a7]">
            Manage all trading plans, investment ranges, and returns
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <span className="text-sm font-medium text-zinc-500 dark:text-[#8b93a7]">
            Total Plans: {plans?.length || 0}
          </span>
          <Link
            href="/admin/plans/create"
            className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-emerald-700"
          >
            <Plus size={16} />
            Add New Plan
          </Link>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative mb-6">
        <Search
          size={18}
          className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 dark:text-[#8b93a7]"
        />
        <input
          type="text"
          placeholder="Search plans by name or description..."
          onChange={handleSearch}
          className="w-full rounded-xl border border-zinc-200 bg-white py-3 pl-10 pr-4 text-sm text-zinc-900 transition-colors focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 dark:border-[#232a3b] dark:bg-[#12161f] dark:text-white dark:placeholder:text-[#8b93a7]"
        />
      </div>

      {/* Table Container */}
      <div className="overflow-hidden rounded-xl border border-zinc-200 bg-white shadow-sm dark:border-[#232a3b] dark:bg-[#12161f]">
        <div className="overflow-x-auto">
          {isLoading ? (
            <div className="flex flex-col items-center gap-4 py-12">
              <div className="h-10 w-10 animate-spin rounded-full border-4 border-zinc-200 border-t-indigo-600 dark:border-[#232a3b] dark:border-t-indigo-400" />
              <p className="text-sm text-zinc-500 dark:text-[#8b93a7]">
                Loading trading plans...
              </p>
            </div>
          ) : plans?.length === 0 ? (
            <div className="flex flex-col items-center gap-4 py-12">
              <Layers
                size={48}
                className="text-zinc-300 opacity-30 dark:text-[#8b93a7]"
              />
              <p className="text-sm text-zinc-500 dark:text-[#8b93a7]">
                No trading plans found
              </p>
              <Link
                href="/admin/plans/create"
                className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-emerald-700"
              >
                <Plus size={16} />
                Create First Plan
              </Link>
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead className="border-b border-zinc-200 bg-zinc-50 dark:border-[#232a3b] dark:bg-[#1a2035]">
                <tr>
                  <th className="whitespace-nowrap px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-[#8b93a7]">
                    Plan Details
                  </th>
                  <th className="whitespace-nowrap px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-[#8b93a7]">
                    Investment Range
                  </th>
                  <th className="whitespace-nowrap px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-[#8b93a7]">
                    Duration & Returns
                  </th>
                  <th className="whitespace-nowrap px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-[#8b93a7]">
                    Status
                  </th>
                  <th className="whitespace-nowrap px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-[#8b93a7]">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                {plans.map((plan) => (
                  <tr
                    key={plan.id}
                    className="border-t border-zinc-200 transition-colors hover:bg-zinc-50 dark:border-[#232a3b] dark:hover:bg-[#1a2035]"
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 min-w-[2.25rem] items-center justify-center rounded-lg bg-gradient-to-br from-indigo-600 to-purple-600 text-white">
                          <Layers size={16} />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="font-semibold text-zinc-900 dark:text-white">
                            {plan.plan_name}
                          </p>
                          <p className="truncate text-xs text-zinc-500 dark:text-[#8b93a7]">
                            {plan.plan_des}
                          </p>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex flex-col gap-0.5">
                        <div className="flex items-center gap-2 text-sm">
                          <span className="text-xs font-medium uppercase tracking-wider text-zinc-500 dark:text-[#8b93a7]">
                            Min
                          </span>
                          <span className="font-semibold text-zinc-900 dark:text-white">
                            {formatAmount(plan.min_ins)}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <span className="text-xs font-medium uppercase tracking-wider text-zinc-500 dark:text-[#8b93a7]">
                            Max
                          </span>
                          <span className="font-semibold text-zinc-900 dark:text-white">
                            {formatAmount(plan.max_ins)}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex flex-col gap-0.5">
                        <div className="flex items-center gap-1.5 text-sm text-zinc-500 dark:text-[#8b93a7]">
                          <Calendar size={14} />
                          <span>{plan.days_duration || "N/A"} Days</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-sm text-zinc-500 dark:text-[#8b93a7]">
                          <TrendingUp size={14} />
                          <span>
                            {plan.daily_interest_rate || "N/A"}% Daily
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium ${
                          plan.status === "active"
                            ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400"
                            : "bg-red-100 text-red-700 dark:bg-red-950/30 dark:text-red-400"
                        }`}
                      >
                        {plan.status === "active" ? (
                          <>
                            <CheckCircle size={12} />
                            Active
                          </>
                        ) : (
                          <>
                            <XCircle size={12} />
                            Inactive
                          </>
                        )}
                      </span>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <Link
                          href={`/admin/plans/${plan.id}`}
                          className="rounded-lg p-2 transition-colors hover:bg-indigo-50 dark:hover:bg-indigo-950/20"
                          title="Edit Plan"
                        >
                          <Edit2
                            size={16}
                            className="text-zinc-400 transition-colors hover:text-indigo-600 dark:text-[#8b93a7] dark:hover:text-indigo-400"
                          />
                        </Link>
                        <button
                          onClick={() => deletePlan(plan.id, plan.plan_name)}
                          className="rounded-lg p-2 transition-colors hover:bg-red-50 dark:hover:bg-red-950/20"
                          title="Delete Plan"
                        >
                          <Trash2
                            size={16}
                            className="text-zinc-400 transition-colors hover:text-red-600 dark:text-[#8b93a7] dark:hover:text-red-400"
                          />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Table Footer */}
        {plans?.length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-zinc-200 bg-zinc-50 px-6 py-3 dark:border-[#232a3b] dark:bg-[#1a2035]">
            <div className="flex flex-wrap items-center gap-4">
              <p className="text-sm text-zinc-500 dark:text-[#8b93a7]">
                Showing {plans.length} of {plans.length} trading plans
              </p>
            </div>
            <div className="flex gap-2">
              <button className="rounded-lg border border-zinc-200 bg-white px-4 py-1.5 text-sm text-zinc-700 transition hover:bg-zinc-50 dark:border-[#232a3b] dark:bg-[#12161f] dark:text-zinc-300 dark:hover:bg-[#1a2035]">
                Previous
              </button>
              <button className="rounded-lg bg-indigo-600 px-4 py-1.5 text-sm text-white transition hover:bg-indigo-700">
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
